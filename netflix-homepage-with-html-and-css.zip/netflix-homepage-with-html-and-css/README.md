# Netflix Homepage with html and css

A Pen created on CodePen.io. Original URL: [https://codepen.io/albenis-k-rqeli/pen/eYNGzvJ](https://codepen.io/albenis-k-rqeli/pen/eYNGzvJ).

Netflix Website maded with only html and css . This Project is 100% responsive and you can try it
